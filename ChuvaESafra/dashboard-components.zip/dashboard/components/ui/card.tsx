import { twMerge } from 'tailwind-merge'
import type { ComponentProps } from 'react'

export interface CardProps extends ComponentProps<'div'> {}

export function Card({ className, ...props }: CardProps) {
	return (
		<div
			data-slot="card"
			className={twMerge(
				'bg-surface flex flex-col gap-4 rounded-xl border border-border p-5',
				className,
			)}
			{...props}
		/>
	)
}

export function CardHeader({ className, ...props }: ComponentProps<'div'>) {
	return (
		<div
			data-slot="card-header"
			className={twMerge('flex items-start justify-between gap-4', className)}
			{...props}
		/>
	)
}

export function CardTitle({ className, ...props }: ComponentProps<'h3'>) {
	return (
		<h3
			data-slot="card-title"
			className={twMerge('text-sm font-semibold text-foreground', className)}
			{...props}
		/>
	)
}

export function CardDescription({ className, ...props }: ComponentProps<'p'>) {
	return (
		<p
			data-slot="card-description"
			className={twMerge('text-xs text-muted-foreground', className)}
			{...props}
		/>
	)
}

export function CardContent({ className, ...props }: ComponentProps<'div'>) {
	return <div data-slot="card-content" className={twMerge('flex-1', className)} {...props} />
}
